package org.apache.commons.io.serialization;

public interface ClassNameMatcher {
   boolean matches(String var1);
}
