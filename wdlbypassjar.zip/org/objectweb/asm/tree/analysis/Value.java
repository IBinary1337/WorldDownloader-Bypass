package org.objectweb.asm.tree.analysis;

public interface Value {
   int getSize();
}
