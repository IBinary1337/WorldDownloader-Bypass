package org.objectweb.asm.tree;

import java.util.ArrayList;
import java.util.List;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.ModuleVisitor;

public class ModuleNode extends ModuleVisitor {
   public String name;
   public int access;
   public String version;
   public String mainClass;
   public List packages;
   public List requires;
   public List exports;
   public List opens;
   public List uses;
   public List provides;

   public ModuleNode(String name, int access, String version) {
      super(393216);
      this.name = name;
      this.access = access;
      this.version = version;
   }

   public ModuleNode(int api, String name, int access, String version, List requires, List exports, List opens, List uses, List provides) {
      super(api);
      this.name = name;
      this.access = access;
      this.version = version;
      this.requires = requires;
      this.exports = exports;
      this.opens = opens;
      this.uses = uses;
      this.provides = provides;
      if (this.getClass() != ModuleNode.class) {
         throw new IllegalStateException();
      }
   }

   public void visitMainClass(String mainClass) {
      this.mainClass = mainClass;
   }

   public void visitPackage(String packaze) {
      if (this.packages == null) {
         this.packages = new ArrayList(5);
      }

      this.packages.add(packaze);
   }

   public void visitRequire(String module, int access, String version) {
      if (this.requires == null) {
         this.requires = new ArrayList(5);
      }

      this.requires.add(new ModuleRequireNode(module, access, version));
   }

   public void visitExport(String packaze, int access, String... modules) {
      if (this.exports == null) {
         this.exports = new ArrayList(5);
      }

      List moduleList = null;
      if (modules != null) {
         moduleList = new ArrayList(modules.length);

         for(int i = 0; i < modules.length; ++i) {
            moduleList.add(modules[i]);
         }
      }

      this.exports.add(new ModuleExportNode(packaze, access, moduleList));
   }

   public void visitOpen(String packaze, int access, String... modules) {
      if (this.opens == null) {
         this.opens = new ArrayList(5);
      }

      List moduleList = null;
      if (modules != null) {
         moduleList = new ArrayList(modules.length);

         for(int i = 0; i < modules.length; ++i) {
            moduleList.add(modules[i]);
         }
      }

      this.opens.add(new ModuleOpenNode(packaze, access, moduleList));
   }

   public void visitUse(String service) {
      if (this.uses == null) {
         this.uses = new ArrayList(5);
      }

      this.uses.add(service);
   }

   public void visitProvide(String service, String... providers) {
      if (this.provides == null) {
         this.provides = new ArrayList(5);
      }

      ArrayList providerList = new ArrayList(providers.length);

      for(int i = 0; i < providers.length; ++i) {
         providerList.add(providers[i]);
      }

      this.provides.add(new ModuleProvideNode(service, providerList));
   }

   public void visitEnd() {
   }

   public void accept(ClassVisitor cv) {
      ModuleVisitor mv = cv.visitModule(this.name, this.access, this.version);
      if (mv != null) {
         if (this.mainClass != null) {
            mv.visitMainClass(this.mainClass);
         }

         int i;
         if (this.packages != null) {
            for(i = 0; i < this.packages.size(); ++i) {
               mv.visitPackage((String)this.packages.get(i));
            }
         }

         if (this.requires != null) {
            for(i = 0; i < this.requires.size(); ++i) {
               ((ModuleRequireNode)this.requires.get(i)).accept(mv);
            }
         }

         if (this.exports != null) {
            for(i = 0; i < this.exports.size(); ++i) {
               ((ModuleExportNode)this.exports.get(i)).accept(mv);
            }
         }

         if (this.opens != null) {
            for(i = 0; i < this.opens.size(); ++i) {
               ((ModuleOpenNode)this.opens.get(i)).accept(mv);
            }
         }

         if (this.uses != null) {
            for(i = 0; i < this.uses.size(); ++i) {
               mv.visitUse((String)this.uses.get(i));
            }
         }

         if (this.provides != null) {
            for(i = 0; i < this.provides.size(); ++i) {
               ((ModuleProvideNode)this.provides.get(i)).accept(mv);
            }
         }

      }
   }
}
