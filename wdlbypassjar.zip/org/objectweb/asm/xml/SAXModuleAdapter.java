package org.objectweb.asm.xml;

import org.objectweb.asm.ModuleVisitor;
import org.xml.sax.helpers.AttributesImpl;

public final class SAXModuleAdapter extends ModuleVisitor {
   private final SAXAdapter sa;

   public SAXModuleAdapter(SAXAdapter sa) {
      super(393216);
      this.sa = sa;
   }

   public void visitMainClass(String mainClass) {
      AttributesImpl att = new AttributesImpl();
      att.addAttribute("", "name", "name", "", mainClass);
      this.sa.addElement("main-class", att);
   }

   public void visitPackage(String packaze) {
      AttributesImpl att = new AttributesImpl();
      att.addAttribute("", "name", "name", "", packaze);
      this.sa.addElement("packages", att);
   }

   public void visitRequire(String module, int access, String version) {
      AttributesImpl att = new AttributesImpl();
      StringBuilder sb = new StringBuilder();
      SAXClassAdapter.appendAccess(access | 2097152, sb);
      att.addAttribute("", "module", "module", "", module);
      att.addAttribute("", "access", "access", "", sb.toString());
      if (version != null) {
         att.addAttribute("", "access", "access", "", version);
      }

      this.sa.addElement("requires", att);
   }

   public void visitExport(String packaze, int access, String... modules) {
      AttributesImpl att = new AttributesImpl();
      StringBuilder sb = new StringBuilder();
      SAXClassAdapter.appendAccess(access | 2097152, sb);
      att.addAttribute("", "name", "name", "", packaze);
      att.addAttribute("", "access", "access", "", sb.toString());
      this.sa.addStart("exports", att);
      if (modules != null && modules.length > 0) {
         String[] var9 = modules;
         int var8 = modules.length;

         for(int var7 = 0; var7 < var8; ++var7) {
            String to = var9[var7];
            AttributesImpl atts = new AttributesImpl();
            atts.addAttribute("", "module", "module", "", to);
            this.sa.addElement("to", atts);
         }
      }

      this.sa.addEnd("exports");
   }

   public void visitOpen(String packaze, int access, String... modules) {
      AttributesImpl att = new AttributesImpl();
      StringBuilder sb = new StringBuilder();
      SAXClassAdapter.appendAccess(access | 2097152, sb);
      att.addAttribute("", "name", "name", "", packaze);
      att.addAttribute("", "access", "access", "", sb.toString());
      this.sa.addStart("opens", att);
      if (modules != null && modules.length > 0) {
         String[] var9 = modules;
         int var8 = modules.length;

         for(int var7 = 0; var7 < var8; ++var7) {
            String to = var9[var7];
            AttributesImpl atts = new AttributesImpl();
            atts.addAttribute("", "module", "module", "", to);
            this.sa.addElement("to", atts);
         }
      }

      this.sa.addEnd("opens");
   }

   public void visitUse(String service) {
      AttributesImpl att = new AttributesImpl();
      att.addAttribute("", "service", "service", "", service);
      this.sa.addElement("uses", att);
   }

   public void visitProvide(String service, String... providers) {
      AttributesImpl att = new AttributesImpl();
      att.addAttribute("", "service", "service", "", service);
      this.sa.addStart("provides", att);
      String[] var7 = providers;
      int var6 = providers.length;

      for(int var5 = 0; var5 < var6; ++var5) {
         String provider = var7[var5];
         AttributesImpl atts = new AttributesImpl();
         atts.addAttribute("", "provider", "provider", "", provider);
         this.sa.addElement("with", atts);
      }

      this.sa.addEnd("provides");
   }

   public void visitEnd() {
      this.sa.addEnd("module");
   }
}
