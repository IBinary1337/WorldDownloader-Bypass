package org.objectweb.asm.commons;

import java.util.ArrayList;
import java.util.List;
import org.objectweb.asm.Attribute;
import org.objectweb.asm.ByteVector;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Label;

public final class ModuleHashesAttribute extends Attribute {
   public String algorithm;
   public List modules;
   public List hashes;

   public ModuleHashesAttribute(String algorithm, List modules, List hashes) {
      super("ModuleHashes");
      this.algorithm = algorithm;
      this.modules = modules;
      this.hashes = hashes;
   }

   public ModuleHashesAttribute() {
      this((String)null, (List)null, (List)null);
   }

   protected Attribute read(ClassReader cr, int off, int len, char[] buf, int codeOff, Label[] labels) {
      String hashAlgorithm = cr.readUTF8(off, buf);
      int count = cr.readUnsignedShort(off + 2);
      ArrayList modules = new ArrayList(count);
      ArrayList hashes = new ArrayList(count);
      off += 4;

      for(int i = 0; i < count; ++i) {
         String module = cr.readModule(off, buf);
         int hashLength = cr.readUnsignedShort(off + 2);
         off += 4;
         byte[] hash = new byte[hashLength];

         for(int j = 0; j < hashLength; ++j) {
            hash[j] = (byte)(cr.readByte(off + j) & 255);
         }

         off += hashLength;
         modules.add(module);
         hashes.add(hash);
      }

      return new ModuleHashesAttribute(hashAlgorithm, modules, hashes);
   }

   protected ByteVector write(ClassWriter cw, byte[] code, int len, int maxStack, int maxLocals) {
      ByteVector v = new ByteVector();
      int index = cw.newUTF8(this.algorithm);
      v.putShort(index);
      int count = this.modules == null ? 0 : this.modules.size();
      v.putShort(count);

      for(int i = 0; i < count; ++i) {
         String module = (String)this.modules.get(i);
         v.putShort(cw.newModule(module));
         byte[] hash = (byte[])this.hashes.get(i);
         v.putShort(hash.length);
         byte[] var15 = hash;
         int var14 = hash.length;

         for(int var13 = 0; var13 < var14; ++var13) {
            byte b = var15[var13];
            v.putByte(b);
         }
      }

      return v;
   }
}
