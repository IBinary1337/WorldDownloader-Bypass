package org.objectweb.asm.commons;

import org.objectweb.asm.Attribute;
import org.objectweb.asm.ByteVector;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Label;

public final class ModuleTargetAttribute extends Attribute {
   public String platform;

   public ModuleTargetAttribute(String platform) {
      super("ModuleTarget");
      this.platform = platform;
   }

   public ModuleTargetAttribute() {
      this((String)null);
   }

   protected Attribute read(ClassReader cr, int off, int len, char[] buf, int codeOff, Label[] labels) {
      String platform = cr.readUTF8(off, buf);
      return new ModuleTargetAttribute(platform);
   }

   protected ByteVector write(ClassWriter cw, byte[] code, int len, int maxStack, int maxLocals) {
      ByteVector v = new ByteVector();
      int index = this.platform == null ? 0 : cw.newUTF8(this.platform);
      v.putShort(index);
      return v;
   }
}
