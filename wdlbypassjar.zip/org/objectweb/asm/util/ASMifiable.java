package org.objectweb.asm.util;

import java.util.Map;

public interface ASMifiable {
   void asmify(StringBuffer var1, String var2, Map var3);
}
