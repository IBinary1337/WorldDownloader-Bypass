package wdl.bypass;

import java.awt.Color;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.function.Predicate;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;
import javax.swing.JLabel;
import org.apache.commons.io.IOUtils;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Type;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.InsnNode;
import org.objectweb.asm.tree.LdcInsnNode;
import org.objectweb.asm.tree.MethodNode;

public class Modder {
   private int succeeded = 0;
   private final File file;
   private final JLabel[] labels;

   public Modder(File file, JLabel... labels) {
      this.file = file;
      this.labels = labels;
   }

   public void startModding() throws IOException {
      if (this.labels.length != 7) {
         throw new RuntimeException();
      } else if (this.file != null && this.file.exists()) {
         String name = this.file.getPath();
         String outName = name.substring(0, name.lastIndexOf(46)) + "Undetectable" + name.substring(name.lastIndexOf(46));
         File out = new File(outName);
         if (out.exists() && !out.delete()) {
            throw new RuntimeException("Could not delete existing output file!");
         } else {
            this.labels[0].setForeground(Color.GREEN);
            this.labels[0].setText("Successfully loaded JAR");
            this.labels[1].setForeground(Color.RED);
            this.labels[1].setText("ClientBrandRetriver not patched");
            this.labels[2].setForeground(Color.RED);
            this.labels[2].setText("WDLPluginChannels sendRequest not patched");
            this.labels[3].setForeground(Color.RED);
            this.labels[3].setText("WDLPluginChannels onWorldLoad not patched");
            this.labels[4].setForeground(Color.RED);
            this.labels[4].setText("WDLPluginChannels onPluginChannelPacket not patched");
            this.labels[5].setForeground(Color.RED);
            this.labels[5].setText("WDLPluginChannels sendInitPacket not patched");
            ZipOutputStream outstream = new ZipOutputStream(new FileOutputStream(out));
            ZipFile zipFile = null;

            try {
               zipFile = new ZipFile(this.file);
               Enumeration enumeration = zipFile.entries();

               while(enumeration.hasMoreElements()) {
                  ZipEntry next = (ZipEntry)enumeration.nextElement();
                  if (!next.isDirectory()) {
                     ZipEntry result = new ZipEntry(next.getName());
                     outstream.putNextEntry(result);
                     if (next.getName().endsWith(".class")) {
                        byte[] classBytes = IOUtils.toByteArray(zipFile.getInputStream(next));
                        outstream.write(this.modify(classBytes));
                     } else {
                        IOUtils.copy((InputStream)zipFile.getInputStream(next), (OutputStream)outstream);
                     }

                     outstream.closeEntry();
                  }
               }
            } catch (Exception var10) {
               this.labels[5].setForeground(Color.RED);
               this.labels[5].setText("Exception while writing file, no file written!");
               outstream.close();
               if (zipFile != null) {
                  zipFile.close();
               }

               out.delete();
               throw var10;
            }

            outstream.close();
            zipFile.close();
            if (this.succeeded >= 5) {
               this.labels[6].setForeground(Color.GREEN);
               this.labels[6].setText("All 5 patchers applied successfully!");
            } else if (this.succeeded > 0) {
               this.labels[6].setForeground(Color.ORANGE);
               this.labels[6].setText(this.succeeded + " out of 5 patchers succeeded!");
            } else {
               this.labels[6].setForeground(Color.RED);
               this.labels[6].setText("No patchers succeeded!");
            }

         }
      } else {
         throw new IllegalArgumentException("Invaild file selected!");
      }
   }

   private byte[] modify(byte[] classBytes) {
      ClassReader reader = new ClassReader(classBytes);
      ClassNode classNode = new ClassNode();
      reader.accept(classNode, 0);
      if (classNode.name.contains("ClientBrandRetriever") && this.modifyBrand(classNode)) {
         ++this.succeeded;
      }

      if (classNode.name.contains("WDLPluginChannels") && !classNode.name.contains("ChunkRange")) {
         this.succeeded += this.modifyPluginChannels(classNode);
      }

      ClassWriter writer = new ClassWriter(0);
      classNode.accept(writer);
      return writer.toByteArray();
   }

   private boolean modifyBrand(ClassNode classNode) {
      MethodNode methodNode = (MethodNode)classNode.methods.stream().filter((method) -> {
         return method.name.equals("getClientModName");
      }).findFirst().orElse((Object)null);
      if (methodNode == null) {
         return false;
      } else {
         methodNode.instructions.clear();
         methodNode.instructions.insert((AbstractInsnNode)(new LdcInsnNode("vanilla")));
         methodNode.instructions.add((AbstractInsnNode)(new InsnNode(176)));
         methodNode.maxStack = 1;
         methodNode.maxLocals = 0;
         this.labels[1].setForeground(Color.GREEN);
         this.labels[1].setText("ClientBrandRetriever patched");
         return true;
      }
   }

   private int modifyPluginChannels(ClassNode classNode) {
      int succeeded = 0;
      MethodNode method1 = (MethodNode)classNode.methods.stream().filter((method) -> {
         return method.name.equals("sendRequests");
      }).findFirst().orElse((Object)null);
      if (method1 != null) {
         method1.instructions.clear();
         method1.tryCatchBlocks.clear();
         method1.localVariables.clear();
         method1.instructions.add((AbstractInsnNode)(new InsnNode(177)));
         method1.maxLocals = 0;
         method1.maxStack = 0;
         this.labels[2].setForeground(Color.GREEN);
         this.labels[2].setText("WDLPluginChannels sendRequests patched");
         ++succeeded;
      }

      MethodNode method2 = (MethodNode)classNode.methods.stream().filter((method) -> {
         return method.name.equals("onWorldLoad");
      }).findFirst().orElse((Object)null);
      if (method2 != null) {
         method2.instructions.clear();
         method2.tryCatchBlocks.clear();
         method2.localVariables.clear();
         method2.instructions.add((AbstractInsnNode)(new InsnNode(177)));
         method2.maxLocals = 0;
         method2.maxStack = 0;
         this.labels[3].setForeground(Color.GREEN);
         this.labels[3].setText("WDLPluginChannels onWorldLoad patched");
         ++succeeded;
      }

      MethodNode method3 = (MethodNode)classNode.methods.stream().filter((method) -> {
         return method.name.equals("onPluginChannelPacket");
      }).findFirst().orElse((Object)null);
      if (method3 != null) {
         method3.instructions.clear();
         method3.tryCatchBlocks.clear();
         method3.localVariables.clear();
         method3.instructions.add((AbstractInsnNode)(new InsnNode(177)));
         method3.maxLocals = 3;
         method3.maxStack = 0;
         this.labels[4].setForeground(Color.GREEN);
         this.labels[4].setText("WDLPluginChannels onPluginChannelPacket patched");
         ++succeeded;
      }

      MethodNode method4 = (MethodNode)classNode.methods.stream().filter((method) -> {
         return method.name.equals("sendInitPacket") && Type.getArgumentTypes(method.desc).length == 2;
      }).findFirst().orElse((Object)null);
      if (method4 != null) {
         method4.instructions.clear();
         method4.tryCatchBlocks.clear();
         method4.localVariables.clear();
         method4.instructions.add((AbstractInsnNode)(new InsnNode(177)));
         method4.maxLocals = 2;
         method4.maxStack = 0;
         this.labels[5].setForeground(Color.GREEN);
         this.labels[5].setText("WDLPluginChannels sendInitPacket patched");
         ++succeeded;
      } else {
         this.labels[5].setForeground(Color.GREEN);
         this.labels[5].setText("WDLPluginChannels sendInitPacket not found - You are patching an older version of WDL");
         ++succeeded;
      }

      return succeeded;
   }
}
