package wdl.bypass;

import java.awt.Color;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.TitledBorder;

public class MainScreen {
   private JFrame frmWdlModder;
   private JTextField textField;
   private File jarPath;

   public static void main(String[] args) {
      EventQueue.invokeLater(new Runnable() {
         public void run() {
            try {
               MainScreen window = new MainScreen();
               window.frmWdlModder.setVisible(true);
            } catch (Exception var2) {
               var2.printStackTrace();
            }

         }
      });
   }

   public MainScreen() {
      this.initialize();
   }

   private void initialize() {
      this.frmWdlModder = new JFrame();
      this.frmWdlModder.setTitle("WDL Modder - UnstoppableH4x");
      this.frmWdlModder.setBounds(100, 100, 475, 400);
      this.frmWdlModder.setDefaultCloseOperation(3);
      this.frmWdlModder.getContentPane().setLayout(new GridBagLayout());

      try {
         UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
      } catch (InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException | ClassNotFoundException var33) {
         var33.printStackTrace();
      }

      JLabel lblSelectYourWorlddownloader = new JLabel("Select your WorldDownloader baseedit ZIP here.");
      GridBagConstraints gbc_selectWDL = new GridBagConstraints();
      gbc_selectWDL.insets = new Insets(5, 5, 2, 0);
      gbc_selectWDL.anchor = 18;
      gbc_selectWDL.gridx = 0;
      gbc_selectWDL.gridy = 0;
      gbc_selectWDL.gridwidth = 2;
      this.frmWdlModder.getContentPane().add(lblSelectYourWorlddownloader, gbc_selectWDL);
      JLabel lblTheOutputFile = new JLabel("The output file will be outputed with an \"Undetectable\" at the end.");
      GridBagConstraints gbc_output = new GridBagConstraints();
      gbc_output.insets = new Insets(0, 5, 2, 0);
      gbc_output.anchor = 18;
      gbc_output.gridx = 0;
      gbc_output.gridy = 1;
      gbc_output.gridwidth = 2;
      this.frmWdlModder.getContentPane().add(lblTheOutputFile, gbc_output);
      JLabel lblThisModderWorks = new JLabel("This modder works best for BASEEDIT WDL versions by pokechu22.");
      GridBagConstraints gbc_best = new GridBagConstraints();
      gbc_best.insets = new Insets(0, 5, 2, 0);
      gbc_best.anchor = 18;
      gbc_best.gridx = 0;
      gbc_best.gridy = 2;
      gbc_best.gridwidth = 2;
      this.frmWdlModder.getContentPane().add(lblThisModderWorks, gbc_best);
      JLabel lblLiteloaderNote = new JLabel("Liteloader versions may not be fully patched.");
      GridBagConstraints gbc_note = new GridBagConstraints();
      gbc_note.insets = new Insets(0, 5, 2, 0);
      gbc_note.anchor = 18;
      gbc_note.gridx = 0;
      gbc_note.gridy = 3;
      gbc_note.gridwidth = 2;
      this.frmWdlModder.getContentPane().add(lblLiteloaderNote, gbc_note);
      this.textField = new JTextField();
      GridBagConstraints gbc_text = new GridBagConstraints();
      gbc_text.insets = new Insets(5, 5, 5, 0);
      gbc_text.anchor = 18;
      gbc_text.fill = 2;
      gbc_text.gridx = 0;
      gbc_text.gridy = 4;
      gbc_text.weightx = 1.0D;
      this.frmWdlModder.getContentPane().add(this.textField, gbc_text);
      this.textField.setColumns(10);
      JButton btnSelect = new JButton("Select");
      GridBagConstraints gbc_select = new GridBagConstraints();
      gbc_select.insets = new Insets(5, 5, 5, 5);
      gbc_select.anchor = 12;
      gbc_select.gridx = 1;
      gbc_select.gridy = 4;
      btnSelect.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            JFileChooser file = new JFileChooser();
            if (MainScreen.this.jarPath != null) {
               file.setSelectedFile(MainScreen.this.jarPath);
            }

            int action = file.showOpenDialog((Component)null);
            if (action == 0) {
               MainScreen.this.jarPath = file.getSelectedFile();
               String path = file.getSelectedFile().toString();
               MainScreen.this.textField.setText(path);
            }

         }
      });
      this.frmWdlModder.getContentPane().add(btnSelect, gbc_select);
      JButton btnBeginModding = new JButton("Begin Modding");
      GridBagConstraints gbc_begin = new GridBagConstraints();
      gbc_begin.gridx = 0;
      gbc_begin.gridy = 5;
      gbc_begin.gridwidth = 2;
      this.frmWdlModder.getContentPane().add(btnBeginModding, gbc_begin);
      JLabel lblOutput = new JLabel("");
      GridBagConstraints gbc_outputLabel = new GridBagConstraints();
      gbc_outputLabel.insets = new Insets(5, 5, 5, 5);
      gbc_outputLabel.fill = 1;
      gbc_outputLabel.gridx = 0;
      gbc_outputLabel.gridy = 6;
      gbc_outputLabel.gridwidth = 2;
      gbc_outputLabel.weightx = 1.0D;
      gbc_outputLabel.weighty = 1.0D;
      TitledBorder selectTitle = new TitledBorder("Output");
      lblOutput.setBorder(selectTitle);
      this.frmWdlModder.getContentPane().add(lblOutput, gbc_outputLabel);
      lblOutput.setLayout(new GridBagLayout());
      final JLabel lblCheckVaild = new JLabel("");
      GridBagConstraints gbc_check = new GridBagConstraints();
      gbc_check.anchor = 18;
      gbc_check.gridx = 0;
      gbc_check.gridy = 0;
      gbc_check.weightx = 1.0D;
      lblOutput.add(lblCheckVaild, gbc_check);
      final JLabel lblBrandMod = new JLabel("");
      GridBagConstraints gbc_brand = new GridBagConstraints();
      gbc_brand.anchor = 18;
      gbc_brand.gridx = 0;
      gbc_brand.gridy = 1;
      gbc_brand.weightx = 1.0D;
      lblOutput.add(lblBrandMod, gbc_brand);
      final JLabel lblSendRequestsMod = new JLabel("");
      GridBagConstraints gbc_requests = new GridBagConstraints();
      gbc_requests.anchor = 18;
      gbc_requests.gridx = 0;
      gbc_requests.gridy = 2;
      gbc_requests.weightx = 1.0D;
      lblOutput.add(lblSendRequestsMod, gbc_requests);
      final JLabel lblWorldLoadMod = new JLabel("");
      GridBagConstraints gbc_world = new GridBagConstraints();
      gbc_world.anchor = 18;
      gbc_world.gridx = 0;
      gbc_world.gridy = 3;
      gbc_world.weightx = 1.0D;
      lblOutput.add(lblWorldLoadMod, gbc_world);
      final JLabel lblPluginChannelsMod = new JLabel("");
      GridBagConstraints gbc_plugin = new GridBagConstraints();
      gbc_plugin.anchor = 18;
      gbc_plugin.gridx = 0;
      gbc_plugin.gridy = 4;
      gbc_plugin.weightx = 1.0D;
      lblOutput.add(lblPluginChannelsMod, gbc_plugin);
      final JLabel lblSendInitPacketMod = new JLabel("");
      GridBagConstraints gbc_initpacket = new GridBagConstraints();
      gbc_initpacket.anchor = 18;
      gbc_initpacket.gridx = 0;
      gbc_initpacket.gridy = 5;
      gbc_initpacket.weightx = 1.0D;
      lblOutput.add(lblSendInitPacketMod, gbc_initpacket);
      final JLabel lblResult = new JLabel("");
      GridBagConstraints gbc_result = new GridBagConstraints();
      gbc_result.anchor = 18;
      gbc_result.gridx = 0;
      gbc_result.gridy = 6;
      gbc_result.weightx = 1.0D;
      lblOutput.add(lblResult, gbc_result);
      JPanel panel = new JPanel();
      GridBagConstraints gbc_panel = new GridBagConstraints();
      gbc_panel.anchor = 18;
      gbc_panel.gridx = 0;
      gbc_panel.gridy = 7;
      gbc_panel.weightx = 1.0D;
      gbc_panel.weighty = 1.0D;
      lblOutput.add(panel, gbc_panel);
      btnBeginModding.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            try {
               lblCheckVaild.setText("");
               lblBrandMod.setText("");
               lblSendRequestsMod.setText("");
               lblWorldLoadMod.setText("");
               lblPluginChannelsMod.setText("");
               lblSendInitPacketMod.setText("");
               lblResult.setText("");
               (new Modder(new File(MainScreen.this.textField.getText()), new JLabel[]{lblCheckVaild, lblBrandMod, lblSendRequestsMod, lblWorldLoadMod, lblPluginChannelsMod, lblSendInitPacketMod, lblResult})).startModding();
            } catch (RuntimeException var3) {
               var3.printStackTrace();
               lblCheckVaild.setForeground(Color.RED);
               if (var3.getMessage() == null) {
                  lblCheckVaild.setText("Internal error");
               } else {
                  lblCheckVaild.setText(var3.getMessage());
               }
            } catch (IOException var4) {
               var4.printStackTrace();
               lblCheckVaild.setForeground(Color.RED);
               if (var4.getMessage() == null) {
                  lblCheckVaild.setText("Error while processing file!");
               } else {
                  lblCheckVaild.setText(var4.getMessage());
               }
            }

         }
      });
   }
}
